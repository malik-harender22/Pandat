# Problem 3
# Part 1
def prefRevCapStr(n) :
    if len(n)==0:
        return n.upper()
    return prefRevCapStr(n[1:])+n[0]
n=str(input("ENTER THE STRING :"))
print(prefRevCapStr(n).upper()," -> ",n)

# Part 2
def scatSubStr(w,s) :
    w=list(w)
    s=list(s)
    l=[]
    i=0
    while i<len(s):
        j=0
        while j <len(w):
            if s[i]==w[j]:
                l.append(s[i])
                del w[:j+1]
                break
            j+=1
        i+=1
    if s==l:
        return "yes"
    else:
        return "false"          
        
w= str(input("ENTER THE STRING GETTING SEARCHED : "))
s=str(input("ENTER THE STRING TO BE SEARCHED FOR : "))
print(scatSubStr(w,s))
