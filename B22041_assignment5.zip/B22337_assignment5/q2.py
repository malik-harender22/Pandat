#Problem 3
#Part 1
import matplotlib.pyplot as plt
import numpy as np
def f(n) :
    if n<2 :
        return 1
    return 1.65*f(n-1)
def g(n):
    if n<2 :
        return 1
    return g(n-1)+g(n-2)
def h(n):
    if n<2:
        return 2
    return 2*h(n-2)
def k(n):
    if n<3:
        return 3
    return k(n-1)+k(n-3)
a=int(input("ENTER THE VALUE OF a "))
b=int(input("ENTER THE VALUE OF b "))
c=int(input("ENTER THE VALUE OF c "))
d=int(input("ENTER THE VALUE OF d "))

print(f(a))
print(g(b))
print(h(c))
print(k(d))

#Part 2

xvalues=[0,1,2,3,4,5,6,7,8,9]
xvalues1=[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29]
yvalues0=[]
yvalues1=[]
yvalues2=[]
yvalues3=[]
yvalues4=[]
yvalues5=[]
yvalues6=[]
yvalues7=[]

for i in range(10) :
    yvalues0.append(f(xvalues[i]))
for i in range(10) :
    yvalues1.append(g(xvalues[i]))
for i in range(10) :
    yvalues2.append(h(xvalues[i]))
for i in range(10) :
    yvalues3.append(k(xvalues[i]))
for i in range(30) :
    yvalues4.append(f(xvalues1[i]))
for i in range(30) :
    yvalues5.append(g(xvalues1[i]))
for i in range(30) :
    yvalues6.append(h(xvalues1[i]))
for i in range(30) :
    yvalues7.append(k(xvalues1[i]))

plt.subplot(511)
plt.scatter(xvalues,yvalues0,color="red")
plt.scatter(xvalues,yvalues1,color="green")
plt.scatter(xvalues,yvalues2,color="orange")
plt.scatter(xvalues,yvalues3,color="blue")
plt.xlim(0,9)
plt.xlabel('x values',fontsize=15)
plt.ylabel('y values',fontsize=15)
plt.title('scatter plot',fontsize=20)
plt.legend(['f(n)','g(n)','h(n)','k(n)'],fontsize=6,loc='upper left')

plt.subplot(513)
plt.plot(xvalues,yvalues0,marker='*',color='red')
plt.plot(xvalues,yvalues1,marker='*',color='green')
plt.plot(xvalues,yvalues2,marker='*',color='orange')
plt.plot(xvalues,yvalues3,marker='*',color='blue')
plt.xlim(0,9)
plt.xlabel('x values',fontsize=15)
plt.ylabel('y values',fontsize=15)
plt.title('graph1',fontsize=20)
plt.legend(['f(n)','g(n)','h(n)','k(n)'],fontsize=7,loc='upper center')

#Part 3
print("For higher ranges of values of x we see that the slope of all these functions keeps on increasing as we go ahead .")
plt.subplot(515)
plt.plot(xvalues1,yvalues4,marker='*',color='red')
plt.plot(xvalues1,yvalues5,marker='*',color='green')
plt.plot(xvalues1,yvalues6,marker='*',color='orange')
plt.plot(xvalues1,yvalues7,marker='*',color='blue')
plt.xlim(0,29)
plt.xlabel('x values',fontsize=15)
plt.ylabel('y values',fontsize=15)
plt.title('graph2',fontsize=20)
plt.legend(['f(n)','g(n)','h(n)','k(n)'],fontsize=7,loc='upper center')
plt.show()
